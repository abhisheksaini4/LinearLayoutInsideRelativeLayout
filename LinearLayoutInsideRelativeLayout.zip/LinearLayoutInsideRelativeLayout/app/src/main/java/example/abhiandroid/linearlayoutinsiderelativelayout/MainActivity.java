package example.abhiandroid.linearlayoutinsiderelativelayout;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener {

    Button firstButton, secondButton, thirdButton, fourthButton;

    // automatically called when the activity is first created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // get the reference of Button's and then perform click event on Button's
        firstButton = (Button) findViewById(R.id.firstButton);
        firstButton.setOnClickListener(this);
        secondButton = (Button) findViewById(R.id.secondButton);
        secondButton.setOnClickListener(this);
        thirdButton = (Button) findViewById(R.id.thirdButton);
        thirdButton.setOnClickListener(this);
        fourthButton = (Button) findViewById(R.id.fourthButton);
        fourthButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String btnName = null;
        // check which button is clicked and set the string value in the variable for displaying it by using a toast
        switch (v.getId()) {
            case R.id.firstButton:
                btnName = "First Button Clicked";
                break;
            case R.id.secondButton:
                btnName = "Second Button Clicked";
                break;
            case R.id.thirdButton:
                btnName = "Third Button Clicked";
                break;
            case R.id.fourthButton:
                btnName = "Fourth Button Clicked";
                break;
        }
        // display the name of clicked Button by using a Toast
        Toast.makeText(getApplicationContext(), btnName, Toast.LENGTH_LONG).show();

    }

}
